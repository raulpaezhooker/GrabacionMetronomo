from Tkinter import *
from Tkinter import Tk
import tkMessageBox
from grabar import Grabar
import pyaudio
import  math
import numpy as np
import wave
import struct





def main():

    CHUNK = 1024
    FORMAT = pyaudio.paInt16
    CHANNELS = 2
    RATE = 44100
    Frecuenciadesampleo = 44100.0
    MaxBits = 16
    Buffer = 1024
    Level = -3
    Nombre='Metronomo'+'.wav'
    Tonoarray=[('Do',261.63),('Do#',277.18),('Reb',277.18),('Re',293.66),('Re#',311.13),('Mib',311.13),
                   ('Mi',329.63),('Fa',349.23),('Fa#',369.99),('Sol',392.00),('Sol#',415.30),('Lab',415.30),('La',440),('La#',466.16),
                   ('Sib',466.16),('Si',493.88),('C',261.63),('C#',277.18),('Db',277.18),('D',293.66),('D#',311.13),('Eb',311.13),
                   ('E',329.63),('F',349.23),('F#',369.99),('G',392.00),('G#',415.30),('Ab',415.30),('A',440),('A#',466.16),
                   ('Bb',466.16),('B',493.88)]



    # Creacion de la ventana

    ventana = Tk()

    ventana.title("Ventana Principal")

    audio1 = Grabar(CHUNK, FORMAT, CHANNELS, RATE)


    d = BooleanVar(ventana)
    e = BooleanVar(ventana)
    e.set(False)
    f = BooleanVar(ventana)
    f.set(False)
    g=BooleanVar(ventana)


    global arreglo1, datos

    arreglo1 = []



    # Uso de frames para organizar la ventana.
    frame1 = Frame(ventana)
    frame1.pack(side=TOP)
    frame2 = Frame(ventana)
    frame2.pack(side=TOP)


    # Creacion e insercion del cuadro de texto 1.


    cuadro1= Label(frame1, fg="black", padx=15, pady=10, text="Nota:")
    cuadro1.pack(side=TOP)
    cuadro5= Label(frame1, fg="red", padx=15, pady=10, text="Ejemplo: Do# o Eb:  ")
    cuadro5.pack(side=TOP)
    Nota=Entry(frame1, bd=5, insertwidth=1)
    Nota.pack(side=TOP, padx=2.5, pady=2.5)



    cuadro2= Label(frame1, fg="black", padx=15, pady=10, text="Tempo ")
    cuadro2.pack(side=TOP)


    Tempo=Entry(frame1, bd=5, insertwidth=1)
    Tempo.pack(side=TOP, padx=2.5, pady=2.5)

    cuadro3= Label(frame1, fg="black", padx=2.5, pady=2.5, text="Metrica: ")
    cuadro3.pack(side=TOP)
    cuadro4= Label(frame1, fg="red", padx=15, pady=10, text="(2,3,4,5)en Cuartos y (6,7,9,12) en Octavos  ")
    cuadro4.pack(side=TOP)

    # Creacion e insercion de cuadro de entrada 1.





    Metrica=Entry(frame1, bd=5, insertwidth=1)
    Metrica.pack(side=TOP, padx=15, pady=10)

    cuadrito= Label(frame1, fg="black", padx=15, pady=10, text="Ajuste el volumen del metro:")
    cuadrito.pack(side=TOP)
    slider=Scale(frame1,from_=10,to=0)
    slider.pack(side=TOP)



    cuadro= Label(frame1, fg="black", padx=15, pady=10, text="Digite el nombre del archivo 1:")
    cuadro.pack(side=LEFT)

    e1 = Entry(frame1, bd=5, insertwidth=1)
    e1.pack(side=LEFT, padx=10, pady=10)

    # Mensajes de grabacion activada.
    mensaje1 = Label(frame1, fg='red', padx=15, pady=10, text='Grabando...')

    # Funcion activa mensaje y grabar


    def activasms1():
        global datos
        wavearray=[]
        FinalData=[]
        if e1.get() == '':
            print 'error'
            tkMessageBox._show('Error', 'No ingreso nombre del audio.')
        else:
            d.set(True)

            Tono=Nota.get()
            Tempo1=Tempo.get()

            Metro=float(Metrica.get())
            Tiempo=(60/float(Tempo1))
            metroarray=[(2,4),(3,4),(4,4),(6,8),(9,8),(12,8),(7,8),(5,8)]
            tamano=int(Tiempo*44100)
            e1.configure(state='disabled')



            mensaje1.pack(side=LEFT)
            for j in Tonoarray:
                if Tono==j[0]:
                        print "coincide el valor "
                        Fundamental=j
                        Tone=Fundamental[1]
                        print Fundamental
            for m in metroarray:
                if Metro==m[0]:
                        print "coincide el valor "
                        metro=m
                        metro1=metro[0]
                        print metro, metro1

            t1=Tone*float(1.059463**8)
            t2= Tone
            if metro[0]==2:

                    t1=Tone*float(1.059463**8)
                    t2=Tone
                    t3=Tone
                    t4=Tone
            wavearray = []
            if metro[0]==2:
                for j in range (0,10):
                    for i in range(0, tamano/2):
                            datos = math.sin((2*math.pi*t1*i)/44100)
                            wavearray.append(datos)

                    for i in range(0, tamano/2):
                            datos =0
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = 0
                            wavearray.append(datos)
                    FinalData = np.asarray(wavearray)
            if metro[0]==3:
                for j in range (0,5):

                    for i in range(0, tamano/2):
                            datos = math.sin((2*math.pi*t1*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = math.sin((2*math.pi*t1*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = 0
                            wavearray.append(datos)
                    FinalData = np.asarray(wavearray)
            if metro[0]==4:
                for j in range (0,5):

                    for i in range(0, tamano/2):
                            datos = math.sin((2*math.pi*t1*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = math.sin((2*math.pi*t1*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = 0
                            wavearray.append(datos)
                    FinalData = np.asarray(wavearray)
            if metro[0]==5:
                for j in range (0,5):

                    for i in range(0, tamano/2):
                            datos = math.sin((2*math.pi*t1*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/2):
                            datos = 0
                            wavearray.append(datos)

                    FinalData = np.asarray(wavearray)
            if metro[0]==6:
                for j in range (0,5):

                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t1*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t1*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)

                    FinalData = np.asarray(wavearray)
            if metro[0]==7:
                for j in range (0,5):

                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t1*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t1*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)

                    FinalData = np.asarray(wavearray)
            if metro[0]==9:
                for j in range (0,5):

                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t1*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)

                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)


                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t1*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)

                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)

                    FinalData = np.asarray(wavearray)


            if metro[0]==12:
                for j in range (0,4):

                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t1*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)

                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t1*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)

                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = math.sin((2*math.pi*t2*i)/44100)
                            wavearray.append(datos)
                    for i in range(0, tamano/6):
                            datos = 0
                            wavearray.append(datos)

                    FinalData = np.asarray(wavearray)







            data=FinalData
            print 'Data', data
            print slider.get()
            if int(slider.get())==0:
                level=-100
            if int(slider.get())==1:
                level=-32
            if int(slider.get())==2:
                level=-28
            if int(slider.get())==3:
                level=-24
            if int(slider.get())==4:
                level=-20
            if int(slider.get())==5:
                level=-16
            if int(slider.get())==6:
                level=-12
            if int(slider.get())==7:
                level=-8
            if int(slider.get())==8:
                level=-4
            if int(slider.get())==9:
                level=-2
            if int(slider.get())==10:
                level=-0.9
            print level
            peaklevel = max(abs(data))
            print peaklevel
            valueLevel = (10**(level/20))*((2**16)/2.0)
            valueAdjust = valueLevel / float(peaklevel)
            datosAjustados = data * valueAdjust
            print max(datosAjustados)
            datos=datosAjustados
            print 'Datos',datos

            output = wave.open(Nombre, 'w')
            Set_Bits = 16/8
            output.setparams((1, Set_Bits, 44100, 0, 'NONE', 'not compressed'))



            values = []
            for i in range(0, len(datos)):

                    packed_value = struct.pack('<h', datos[i])

                    values.append(packed_value)

        value_str = ''.join(values)
        output.writeframes(value_str)
        output.close()

        audio1.inicio()
        rf = wave.open(Nombre, 'rb')
        prof = rf.getsampwidth()
        channels = rf.getnchannels()
        rate = rf.getframerate()
        audioN = pyaudio.PyAudio()
        streamN = audioN.open(format=audioN.get_format_from_width(prof), channels=channels, rate=rate, output=True)
        datos = rf.readframes(1024)

        while datos != '':

            while d.get():
                audio1.grabacion()
                streamN.write(datos)
                datos = rf.readframes(1024)
                ventana.update()




                if d.get() is False:
                    break


        rf.close()
        streamN.stop_stream()
        streamN.close()
        audioN.terminate()















    # Funcion desactiva mensaje y para de grabar.
    def desactivasms1():
        d.set(False)
        e.set(True)
        global datos
        datos= ''
        mensaje1.pack_forget()
        global  arreglo1
        arreglo1 = audio1.parar()

        audio1.creaAudio(e1.get())
        grabarButton1.pack_forget()
        pararButton1.pack_forget()





    def reproduccion1():
        audio1.reproduce(e1.get())




    # Creacion de botones.
    grabarButton1 = Button(frame2, padx=30, pady=2, text="Grabar", command=activasms1)
    grabarButton1.pack(side=LEFT)

    pararButton1 = Button(frame2, padx=30, pady=2, text="Parar", command=desactivasms1)
    pararButton1.pack(side=LEFT)

    reproducirButton1 = Button(frame2, padx=20,pady=2, text="Reproducir", command=reproduccion1)
    reproducirButton1.pack(side=RIGHT)






    ventana.mainloop()

if __name__ == "__main__":
    main()